import fs from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import vm from 'node:vm';
const root=path.dirname(fileURLToPath(import.meta.url));
const output=path.join(root,'_site');
const baseArg=process.argv[process.argv.indexOf('--base')+1];
const originArg=process.argv[process.argv.indexOf('--origin')+1];
if(!process.argv.includes('--base')||!process.argv.includes('--origin'))throw Error('Use --base /repository/ --origin https://owner.github.io');
const base=baseArg.replace(/\/$/,'');
const origin=new URL(originArg).origin;
const errors=[];let checked=0,htmlCount=0;
async function walk(dir){const out=[];for(const e of await fs.readdir(dir,{withFileTypes:true})){const file=path.join(dir,e.name);if(e.isDirectory())out.push(...await walk(file));else out.push(file);}return out;}
const inventory=await walk(output);
const available=new Set(inventory.map(f=>path.relative(output,f).replaceAll('\\','/')));
function checkURL(raw,file){
 if(!raw||/^(?:#|data:|mailto:|tel:|javascript:)/i.test(raw))return;
 let url;try{url=new URL(raw,origin+base+'/'+file);}catch{errors.push(`${file}: invalid URL`);return;}
 if(url.origin!==origin)return;
 checked++;
 if(base&&url.pathname!==base&&!url.pathname.startsWith(base+'/')){errors.push(`${file}: URL escapes base ${url.pathname}`);return;}
 let name;try{name=decodeURIComponent(url.pathname.slice(base.length)).replace(/^\//,'');}catch{errors.push(`${file}: URL decode`);return;}
 if(name===''||name.endsWith('/'))name+='index.html';
 if(!available.has(name)&&!available.has(name+'/index.html'))errors.push(`${file}: missing ${name}`);
}
const secretPatterns=[/\bgh[pousr]_[A-Za-z0-9]{30,}/g,/\bgithub_pat_[A-Za-z0-9_]{40,}/g,/\bsk-[A-Za-z0-9_-]{30,}/g,/\bAKIA[A-Z0-9]{16}/g,/-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----/g,/Bearer\s+[A-Za-z0-9._-]{24,}/g];
function sameURL(actual,expected){try{const a=new URL(actual),b=new URL(expected);return a.origin===b.origin&&decodeURIComponent(a.pathname)===decodeURIComponent(b.pathname)&&a.search===b.search&&a.hash===b.hash;}catch{return false;}}
let secretFiles=0;
for(const file of inventory){
 const name=path.relative(output,file).replaceAll('\\','/');
 if(/(^|\/)(?:downloads|\.git|\.openai|research|wordpress-theme|node_modules)(\/|$)/.test(name)||/\.(?:sql|zip|php|env)$/i.test(name))errors.push(`${name}: forbidden file`);
 if(!/\.(?:html|js|mjs|css|json|txt|md|svg)$/.test(name))continue;
 const text=await fs.readFile(file,'utf8');
 if(secretPatterns.some(pattern=>{pattern.lastIndex=0;return pattern.test(text);}))secretFiles++;
 if(/https?:\/\/(?:chat\.openai\.com|chatgpt\.com)\/c\//i.test(text))errors.push(`${name}: private conversation URL`);
 if(/\/wp-admin\b|wp-config\.php/i.test(text))errors.push(`${name}: admin URL`);
 if(name.endsWith('.html')){
  htmlCount++;
  if(!/<meta\s+name="robots"\s+content="noindex,nofollow">/i.test(text))errors.push(`${name}: missing noindex`);
  const canonical=text.match(/<link\s+rel="canonical"\s+href="([^"]+)"/i)?.[1];
  const expected=origin+base+'/'+(name==='404.html'?'':name.replace(/index\.html$/,''));
  if(!sameURL(canonical,expected))errors.push(`${name}: incorrect canonical`);
  const ogURL=text.match(/<meta\s+property="og:url"\s+content="([^"]+)"/i)?.[1];
  if(!sameURL(ogURL,expected))errors.push(`${name}: incorrect og:url`);
  for(const m of text.matchAll(/\b(?:href|src|action|poster|data-search-url)=(['"])(.*?)\1/gi))checkURL(m[2],name);
  for(const m of text.matchAll(/\bsrcset=(['"])(.*?)\1/gi))for(const item of m[2].split(','))checkURL(item.trim().split(/\s+/)[0],name);
 }
 if(name.endsWith('.css')){
  for(const m of text.matchAll(/url\(\s*['"]?([^)'"\s]+)['"]?\s*\)/g))checkURL(m[1],name);
  for(const m of text.matchAll(/@import\s+['"]([^'"]+)['"]/g))checkURL(m[1],name);
 }
 if(name==='app.js')for(const m of text.matchAll(/(?:fetch|import)\((['"])([^'"]+)\1/g))checkURL(m[2],name);
 if(name==='search-index.json')for(const item of JSON.parse(text))checkURL(item.url,name);
}
if(secretFiles)errors.push(`High-confidence secret patterns in ${secretFiles} files (values suppressed)`);
if(htmlCount!==586)errors.push(`Expected 586 HTML, found ${htmlCount}`);
if((await fs.readFile(path.join(output,'robots.txt'),'utf8')).trim()!=='User-agent: *\nDisallow: /')errors.push('robots.txt must block crawlers');
// Execute the deployed navigation code against actual prefixed route fixtures.
const app=await fs.readFile(path.join(output,'app.js'),'utf8');
const navStart=app.indexOf("const appLinks=$$('.app-nav a')");
const navEnd=app.indexOf('const tocLinks=',navStart);
if(navStart<0||navEnd<0)errors.push('Navigation fixture cannot locate source code');
let navCases=0;
if(navStart>=0&&navEnd>navStart){
 const code=app.slice(navStart,navEnd);
 for(const [route,context,expected] of [['/','home','home'],['/uslugi/','catalog','services'],['/uslugi/obekty-kulturnogo-naslediya/','service','services'],['/o-nas/','company','more'],['/o-nas/','','more'],['/liczenzii/','licenses','more'],['/privacy-policy/','legal','more'],['/credits/','','more'],['/eko-restavracziya-kak-sohranit-pamyatniki-ne-navrediv-prirode/','journal','articles'],['/kontakty/','contacts','contacts']]){
  const makeLink=(id,pathname)=>({id,href:origin+base+pathname,attrs:{},setAttribute(k,v){this.attrs[k]=v;},removeAttribute(k){delete this.attrs[k];}});
  const links=[makeLink('home','/'),makeLink('services','/uslugi/'),makeLink('articles','/category/stati/'),makeLink('contacts','/kontakty/')];
  const more=makeLink('more','/');
  try{
   vm.runInNewContext(code,{$$:selector=>selector==='.app-nav a'?links:selector==='[data-more]'?[more]:[],document:{body:{dataset:{page:context}}},location:{pathname:base+route},URL});
   const selected=[...links,more].filter(link=>link.attrs['aria-current']==='page').map(link=>link.id);
   if(selected.length!==1||selected[0]!==expected)errors.push(`Active navigation failed: ${base+route}`);
  }catch{errors.push(`Active navigation execution failed: ${base+route}`);}
  navCases++;
 }
}
console.log(JSON.stringify({result:errors.length?'FAIL':'PASS',html:htmlCount,checkedLocalURLs:checked,executedNavigationCases:navCases,files:inventory.length,secretPatternMatches:secretFiles,errors:errors.slice(0,30)},null,2));
if(errors.length)process.exitCode=1;

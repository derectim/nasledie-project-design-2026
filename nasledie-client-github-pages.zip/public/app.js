document.documentElement.classList.add('js');
const $=(s,r=document)=>r.querySelector(s), $$=(s,r=document)=>[...r.querySelectorAll(s)];
let lenis,animationFrame,motionState,motionGeneration=0,motionPageActive=true;
const motion=matchMedia('(prefers-reduced-motion: reduce)');
const fine=matchMedia('(pointer: fine)');
const serviceMenus=$$('[data-service-menu]');
for(const menu of serviceMenus){
 const summary=$('summary',menu);if(!summary)continue;
 menu.addEventListener('toggle',()=>{if(menu.open)serviceMenus.filter(other=>other!==menu).forEach(other=>other.open=false);});
 menu.addEventListener('click',event=>{if(event.target.closest('[data-service-panel] a'))menu.open=false;});
}
document.addEventListener('pointerdown',event=>{serviceMenus.filter(menu=>menu.open&&!menu.contains(event.target)).forEach(menu=>menu.open=false);});
document.addEventListener('focusin',event=>{serviceMenus.filter(menu=>menu.open&&!menu.contains(event.target)).forEach(menu=>menu.open=false);});
document.addEventListener('keydown',event=>{
 if(event.key!=='Escape'||$('dialog[open]'))return;
 const menu=serviceMenus.find(menu=>menu.open);if(!menu)return;
 event.preventDefault();menu.open=false;$('summary',menu)?.focus({preventScroll:true});
});
addEventListener('resize',()=>{serviceMenus.filter(menu=>menu.open&&!$('summary',menu)?.getClientRects().length).forEach(menu=>menu.open=false);},{passive:true});
const searchDialog=$('#search-dialog'), briefDialog=$('#brief-dialog'), cookieDialog=$('#cookie-dialog'), moreDialog=$('#more-dialog');
let returnFocus;
function openDialog(dialog,trigger){
 if(!dialog)return;
 const nextFocus=trigger?.closest('#more-dialog')?$('[data-more]'):trigger?.closest('[data-service-menu]')?.querySelector('summary')||trigger;
 $$('[data-service-menu][open]').forEach(menu=>menu.open=false);
 $$('dialog[open]').filter(other=>other!==dialog).forEach(other=>other.close());
 returnFocus=nextFocus;dialog.showModal();lenis?.stop();
 if(dialog===moreDialog)$('[data-more]')?.setAttribute('aria-expanded','true');
 if(dialog===searchDialog&&fine.matches)$('#global-search',dialog)?.focus({preventScroll:true});
}
for(const dialog of [searchDialog,briefDialog,cookieDialog,moreDialog]){
 dialog?.addEventListener('close',()=>{
  if(dialog===moreDialog)$('[data-more]')?.setAttribute('aria-expanded','false');
  if(!$('dialog[open]')){lenis?.start();if(returnFocus?.getClientRects().length)returnFocus.focus();else $('.brand a[href],a.brand[href]')?.focus();}
 });
 dialog?.addEventListener('click',event=>{if(event.target===dialog){const r=dialog.getBoundingClientRect();if(event.clientX<r.left||event.clientX>r.right||event.clientY<r.top||event.clientY>r.bottom)dialog.close();}});
 dialog?.setAttribute('data-lenis-prevent','');
}
$$('[data-more]').forEach(button=>button.addEventListener('click',()=>openDialog(moreDialog,button)));
$$('[data-brief]').forEach(button=>button.addEventListener('click',event=>{event.preventDefault();if(button.dataset.task)$('[name="task"]',briefDialog).value=button.dataset.task;openDialog(briefDialog,button);}));
document.addEventListener('keydown',e=>{if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==='k'){e.preventDefault();openSearch(document.activeElement);}});
let searchIndex,searchPromise;
async function loadSearch(){if(searchIndex)return searchIndex;if(!searchPromise)searchPromise=fetch('/search-index.json').then(r=>{if(!r.ok)throw Error('search-unavailable');return r.json();}).then(data=>searchIndex=data).catch(error=>{searchPromise=null;throw error;});return searchPromise;}
function normal(s){return s.toLowerCase().replaceAll('ё','е').trim();}
function renderSearch(data,query=''){const words=normal(query).split(/\s+/).filter(Boolean);const found=data.filter(x=>words.every(w=>normal(x.title+' '+x.keywords+' '+x.type).includes(w)));const root=$('#search-results');root.replaceChildren();$('#search-count').textContent=query?`Найдено: ${found.length}`:'Услуги и опубликованные материалы';for(const item of found.slice(0,30)){const a=document.createElement('a');a.className='search-result';a.href=item.url;const text=document.createElement('div'),title=document.createElement('strong'),type=document.createElement('span');title.textContent=item.title;type.textContent=item.type;text.append(title,type);const arrow=document.createElement('span');arrow.textContent='↗';arrow.setAttribute('aria-hidden','true');a.append(text,arrow);root.append(a);}if(!found.length){const p=document.createElement('p');p.className='no-results';p.textContent='Ничего не найдено. Попробуйте «реставрация», «проект» или «дерево».';root.append(p);}}
function searchError(){$('#search-count').textContent='Поиск временно недоступен. Все услуги можно найти в каталоге.';const a=document.createElement('a');a.href='/uslugi/';a.className='text-link';a.textContent='Открыть каталог услуг';$('#search-results').replaceChildren(a);}
async function openSearch(trigger){openDialog(searchDialog,trigger);$('#search-count').textContent='Загружаем услуги…';try{renderSearch(await loadSearch(),$('#global-search').value);}catch{searchError();}}
$$('[data-search]').forEach(b=>b.addEventListener('click',()=>openSearch(b)));
$('#global-search')?.addEventListener('input',async e=>{try{renderSearch(await loadSearch(),e.target.value);}catch{searchError();}});
const filterButtons=$$('[data-filter]'), rows=$$('.service-row'), catalogSearch=$('#catalog-search');
let selectedGroup='all';
function applyFilter(){const words=normal(catalogSearch?.value||'').split(/\s+/).filter(Boolean);let count=0;rows.forEach(row=>{const match=(selectedGroup==='all'||row.dataset.group===selectedGroup)&&words.every(w=>normal(row.textContent).includes(w));const visible=match&&!(document.body.dataset.page==='home'&&selectedGroup==='all'&&count>=6);row.hidden=!visible;if(visible)count++;});filterButtons.forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.filter===selectedGroup)));$$('.no-results').forEach(n=>n.hidden=count>0);const status=$('[data-catalog-count]');if(status)status.textContent=`Найдено услуг: ${count}`;}
function readFilterUrl(){if(!catalogSearch)return;const query=new URL(location.href).searchParams;const requested=query.get('group')||'all';selectedGroup=filterButtons.some(b=>b.dataset.filter===requested)?requested:'all';catalogSearch.value=(query.get('q')||'').slice(0,100);}
function writeFilterUrl(push=false){if(!catalogSearch)return;const url=new URL(location.href);selectedGroup==='all'?url.searchParams.delete('group'):url.searchParams.set('group',selectedGroup);catalogSearch.value.trim()?url.searchParams.set('q',catalogSearch.value.trim()):url.searchParams.delete('q');if(url.href!==location.href)history[push?'pushState':'replaceState']({},'',url);}
filterButtons.forEach(b=>b.addEventListener('click',()=>{selectedGroup=b.dataset.filter;applyFilter();writeFilterUrl(true);}));
catalogSearch?.addEventListener('input',()=>{applyFilter();writeFilterUrl();});
readFilterUrl();if(rows.length)applyFilter();
addEventListener('popstate',()=>{readFilterUrl();if(rows.length)applyFilter();});
$('[data-reset-filter]')?.addEventListener('click',()=>{selectedGroup='all';catalogSearch.value='';applyFilter();writeFilterUrl();catalogSearch.focus();});
const briefForm=$('#brief-form'), formStatus=$('#form-status');
const leadConfig=window.NasledieTheme||{};
const briefFieldNames=['name','phone','email','object','city','task','message','consent'];
const briefErrors=new Map();
const contactRequired='Укажите телефон или электронную почту для ответа.';
const leadUnavailable='Не удалось связаться с сайтом. Повторите попытку или напишите на info@nasledieproekt.ru.';
function briefField(name){return briefFieldNames.includes(name)?briefForm?.elements.namedItem(name):null;}
function clearBriefError(name){
 const error=briefErrors.get(name);if(!error)return;
 error.field.removeAttribute('aria-invalid');
 const descriptions=(error.field.getAttribute('aria-describedby')||'').split(/\s+/).filter(id=>id&&id!==error.note.id);
 if(descriptions.length)error.field.setAttribute('aria-describedby',descriptions.join(' '));else error.field.removeAttribute('aria-describedby');
 error.note.remove();briefErrors.delete(name);
}
function clearBriefErrors(){[...briefErrors.keys()].forEach(clearBriefError);}
function showBriefErrors(errors){
 clearBriefErrors();let first;
 for(const name of briefFieldNames){
  const field=briefField(name),message=errors?.[name];
  if(!field||typeof message!=='string'||!message.trim())continue;
  const label=field.closest('label');if(!label)continue;
  const note=document.createElement('span');note.className='field-error';note.id='brief-error-'+name;note.textContent=message.slice(0,500);label.append(note);
  field.setAttribute('aria-invalid','true');
  field.setAttribute('aria-describedby',[(field.getAttribute('aria-describedby')||'').trim(),note.id].filter(Boolean).join(' '));
  briefErrors.set(name,{field,note});first??=field;
 }
 first?.focus();return briefErrors.size;
}
function clearEditedBriefError(event){
 const name=event.target.name;if(!briefFieldNames.includes(name))return;
 clearBriefError(name);
 if((name==='phone'||name==='email')&&(briefField('phone').value.trim()||briefField('email').value.trim())){
  const other=name==='phone'?'email':'phone';if(briefErrors.get(other)?.note.textContent===contactRequired)clearBriefError(other);
 }
 formStatus.textContent='';
}
briefForm?.addEventListener('input',clearEditedBriefError);
briefForm?.addEventListener('change',clearEditedBriefError);
async function readLeadResponse(response){
 const result=await response.json();
 if(!result||typeof result!=='object'||Array.isArray(result))throw Error('invalid-lead-response');
 return result;
}
function leadResponseMessage(result,fallback=leadUnavailable){
 const expected=typeof result.code==='string'&&result.code.startsWith('nasledie_lead_')||result.status==='accepted';
 return expected&&typeof result.message==='string'&&result.message.trim()&&result.message.length<=500&&!/[<>]/.test(result.message)?result.message:fallback;
}
if(leadConfig.leadUrl){$('[data-form-mode]').textContent='Оставьте контакт для ответа и кратко опишите задачу.';$('[data-submit-label]').firstChild.textContent='Отправить обращение ';}
else if(window.NasledieTheme){$('[data-form-mode]').textContent='Прием обращений через форму пока не включен. Свяжитесь с компанией по электронной почте или телефону.';briefForm.hidden=true;}
briefForm?.addEventListener('submit',async event=>{
 event.preventDefault();
 const fields=Object.fromEntries(new FormData(briefForm));
 clearBriefErrors();formStatus.textContent='';
 const errors={};
 if(!fields.phone?.trim()&&!fields.email?.trim()){errors.phone=contactRequired;errors.email=contactRequired;}
 if(!fields.consent)errors.consent='Для отправки обращения необходимо отдельное согласие на обработку данных.';
 if(showBriefErrors(errors)){formStatus.textContent='Проверьте отмеченные поля.';return;}
 if(!leadConfig.leadUrl){formStatus.textContent='Форма заполнена корректно. Это предпросмотр: данные никуда не отправлены. Для связи используйте электронную почту или телефон.';return;}
 const submit=$('[type="submit"]',briefForm);submit.disabled=true;formStatus.textContent='Отправляем обращение…';
 try{
  const tokenResponse=await fetch(leadConfig.leadTokenUrl,{credentials:'same-origin',cache:'no-store'});
  const token=await readLeadResponse(tokenResponse);
  if(!tokenResponse.ok){formStatus.textContent=leadResponseMessage(token);return;}
  if(typeof token.nonce!=='string'||!token.nonce||typeof token.csrfToken!=='string'||!token.csrfToken)throw Error('invalid-lead-token');
  const response=await fetch(leadConfig.leadUrl,{method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/json'},body:JSON.stringify({...fields,_nasledie_nonce:token.nonce,csrf_token:token.csrfToken})});
  const result=await readLeadResponse(response);
  if(!response.ok){if(result.code==='nasledie_lead_validation')showBriefErrors(result.data?.fields);formStatus.textContent=leadResponseMessage(result);return;}
  if(result.status!=='accepted')throw Error('invalid-lead-receipt');
  clearBriefErrors();briefForm.reset();formStatus.textContent=leadResponseMessage(result);
 }catch{formStatus.textContent=leadUnavailable;}
 finally{submit.disabled=false;}
});
const cookieBanner=$('#cookie-banner');
let preferences={version:1,preferences:false};
try{const stored=JSON.parse(localStorage.getItem('nasledie:consent')||'null');if(stored?.version===1)preferences=stored;else if(cookieBanner)cookieBanner.hidden=false;}catch{if(cookieBanner)cookieBanner.hidden=false;}
function savePreferences(allow){preferences={version:1,preferences:allow,updated:new Date().toISOString()};try{localStorage.setItem('nasledie:consent',JSON.stringify(preferences));if(!allow)Object.keys(localStorage).filter(k=>k.startsWith('nasledie:reading:')).forEach(k=>localStorage.removeItem(k));}catch{}cookieBanner.hidden=true;cookieDialog?.close();updateSaved();}
$$('[data-cookie-settings]').forEach(b=>b.addEventListener('click',()=>{$('#cookie-preferences').checked=!!preferences.preferences;openDialog(cookieDialog,b);}));
$$('[data-cookie-necessary]').forEach(b=>b.addEventListener('click',()=>savePreferences(false)));
$('[data-cookie-save]')?.addEventListener('click',()=>savePreferences($('#cookie-preferences').checked));
const saveButton=$('[data-save]');let saved=false;
function updateSaved(){if(!saveButton)return;try{saved=preferences.preferences&&localStorage.getItem('nasledie:reading:'+location.pathname)==='saved';}catch{saved=false;}saveButton.setAttribute('aria-pressed',String(saved));saveButton.firstChild.textContent=saved?'Материал сохранён ':'Сохранить материал ';}
updateSaved();
saveButton?.addEventListener('click',()=>{if(!preferences.preferences){$('#cookie-preferences').checked=true;openDialog(cookieDialog,saveButton);return;}try{saved=!saved;localStorage.setItem('nasledie:reading:'+location.pathname,saved?'saved':'');updateSaved();}catch{$('[data-save-note]').textContent='Хранилище браузера недоступно';}});
const appLinks=$$('.app-nav a'),pageContext=document.body.dataset.page;
const appHomePath=appLinks[0]?new URL(appLinks[0].href).pathname:'/';
const journalLink=appLinks.find(a=>/\/category\/stati\/?$/.test(new URL(a.href).pathname));
const currentAppLink=pageContext==='journal'?journalLink:appLinks.filter(a=>{const path=new URL(a.href).pathname;return location.pathname===path||(path!==appHomePath&&location.pathname.startsWith(path));}).sort((a,b)=>b.href.length-a.href.length)[0];
appLinks.forEach(a=>{if(a===currentAppLink)a.setAttribute('aria-current','page');else a.removeAttribute('aria-current');});
const morePaths=['/o-nas/','/liczenzii/','/privacy-policy/','/soglasie-na-obrabotku-personalnyh-dannyh/','/obrabotka-personalnyh-dannyh/','/credits/'];
const moreIsCurrent=!currentAppLink&&(['company','licenses','legal','credits'].includes(pageContext)||morePaths.some(path=>location.pathname===path||location.pathname.endsWith(path)));
$$('[data-more]').forEach(button=>{if(moreIsCurrent)button.setAttribute('aria-current','page');else button.removeAttribute('aria-current');});
const tocLinks=$$('.document-nav nav a');
const observed=tocLinks.map(a=>{try{return document.getElementById(decodeURIComponent(a.hash.slice(1)));}catch{return null;}}).filter(Boolean);
let intersectionObserver;
if(observed.length){intersectionObserver=new IntersectionObserver(entries=>{const visible=entries.filter(e=>e.isIntersecting).sort((a,b)=>a.boundingClientRect.top-b.boundingClientRect.top)[0];if(visible)tocLinks.forEach(a=>{const active=a.hash==='#'+visible.target.id;a.classList.toggle('active',active);if(active)a.setAttribute('aria-current','location');else a.removeAttribute('aria-current');});},{rootMargin:'-120px 0px -60% 0px',threshold:0});observed.forEach(e=>intersectionObserver.observe(e));}
const progress=$('.reading-progress span');let progressPending=false;
function updateProgress(){if(!progress)return;const main=$('.prose');const rect=main.getBoundingClientRect(),length=main.scrollHeight-innerHeight+120;progress.style.transform=`scaleX(${Math.min(1,Math.max(0,(120-rect.top)/Math.max(1,length)))})`;progressPending=false;}
function onScroll(){if(progress&&!progressPending){progressPending=true;animationFrame=requestAnimationFrame(updateProgress);}}
addEventListener('scroll',onScroll,{passive:true});addEventListener('resize',onScroll,{passive:true});updateProgress();
async function setupMotion(){
 if(motion.matches||!motionPageActive||motionState)return;
 const state={generation:++motionGeneration,lenis:null,context:null,gsap:null,scrollTrigger:null,ticker:null,onScroll:null,raf:0,refreshRaf:0,images:[],refresh:null};
 motionState=state;
 const current=()=>motionState===state&&state.generation===motionGeneration&&motionPageActive&&!motion.matches;
 try{
  if(fine.matches){
   const {default:Lenis}=await import('/vendor/lenis.mjs');
   if(!current())return;
   state.lenis=new Lenis({duration:.85,smoothWheel:true,syncTouch:false,anchors:true,autoRaf:false});lenis=state.lenis;
   if($('dialog[open]'))lenis.stop();
  }
  if(!current())return;
  if(window.gsap&&window.ScrollTrigger){
   state.gsap=window.gsap;state.scrollTrigger=window.ScrollTrigger;state.gsap.registerPlugin(state.scrollTrigger);
   if(state.lenis){
    state.onScroll=()=>{if(current())state.scrollTrigger.update();};state.lenis.on('scroll',state.onScroll);
    state.ticker=time=>{if(current())state.lenis.raf(time*1000);};state.gsap.ticker.add(state.ticker);state.gsap.ticker.lagSmoothing(0);
   }
   state.context=state.gsap.context(()=>{});
   state.context.add(()=>{
    $$('.reveal-image').forEach(figure=>{const img=$('img',figure);if(img)state.gsap.fromTo(img,{scale:1.025},{scale:1,duration:.85,ease:'power2.out',scrollTrigger:{trigger:figure,start:'top 94%',once:true}});});
    const heroCopy=$$('.strict-home-hero .studio-home-copy > .eyebrow,.strict-home-hero .studio-home-copy > h1,.strict-home-hero .studio-home-copy > .home-position,.strict-home-hero .studio-home-copy > p:not(.eyebrow):not(.home-position),.strict-home-hero .studio-home-copy > .hero-actions');
    if(heroCopy.length)state.gsap.fromTo(heroCopy,{y:12,opacity:.85},{y:0,opacity:1,duration:.65,stagger:.07,ease:'power2.out',clearProps:'transform,opacity'});
   });
   state.refresh=()=>{
    if(!current()||state.refreshRaf)return;
    state.refreshRaf=requestAnimationFrame(()=>{state.refreshRaf=0;if(current()){state.lenis?.resize();state.scrollTrigger.refresh();}});
   };
   state.images=$$('img').filter(img=>!img.complete);
   state.images.forEach(img=>{img.addEventListener('load',state.refresh,{once:true});img.addEventListener('error',state.refresh,{once:true});});
   document.fonts?.ready.then(()=>{if(current())state.refresh();}).catch(()=>{});
   state.refresh();
  }else if(state.lenis){
   const raf=time=>{if(!current())return;state.lenis.raf(time);state.raf=requestAnimationFrame(raf);};
   state.raf=requestAnimationFrame(raf);
  }
 }catch{if(motionState===state)cleanupMotion();/* Native scrolling and complete HTML remain available. */}
}
function cleanupMotion(){
 ++motionGeneration;const state=motionState;motionState=null;if(!state)return;
 cancelAnimationFrame(state.raf);cancelAnimationFrame(state.refreshRaf);
 state.images.forEach(img=>{img.removeEventListener('load',state.refresh);img.removeEventListener('error',state.refresh);});
 if(state.ticker)state.gsap.ticker.remove(state.ticker);
 if(state.onScroll)state.lenis?.off('scroll',state.onScroll);
 try{state.context?.revert();}finally{state.lenis?.destroy();if(lenis===state.lenis)lenis=null;}
}
motion.addEventListener('change',()=>{cleanupMotion();if(!motion.matches)setupMotion();});
addEventListener('pagehide',()=>{motionPageActive=false;cleanupMotion();intersectionObserver?.disconnect();cancelAnimationFrame(animationFrame);removeEventListener('scroll',onScroll);removeEventListener('resize',onScroll);});
addEventListener('pageshow',event=>{if(event.persisted){motionPageActive=true;observed.forEach(e=>intersectionObserver?.observe(e));addEventListener('scroll',onScroll,{passive:true});addEventListener('resize',onScroll,{passive:true});progressPending=false;updateProgress();setupMotion();}});
setupMotion();

import fs from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';

const root=path.dirname(fileURLToPath(import.meta.url));
const input=path.join(root,'public');
const output=path.join(root,'_site');
const args=process.argv.slice(2);
function argument(name){const at=args.indexOf(name);if(at<0)return;const value=args[at+1];if(value===undefined||value.startsWith('--'))throw Error(`Missing ${name} value`);return value;}
for(let i=0;i<args.length;i+=2)if(!['--base','--origin'].includes(args[i]))throw Error(`Unknown option: ${args[i]}`);
const repository=process.env.GITHUB_REPOSITORY||'';
const [owner,repo]=repository.split('/');
let base=argument('--base')??process.env.GITHUB_PAGES_BASE??(repo?(repo.toLowerCase()===`${owner}.github.io`.toLowerCase()?'':`/${repo}`):undefined);
if(base===undefined)throw Error('Set GITHUB_REPOSITORY=owner/repository or pass --base /repository/ --origin https://owner.github.io');
if(base==='/'||base==='')base='';else{
 if(!/^\/?[a-zA-Z0-9._~!$&'()*+,;=@%/-]+\/?$/.test(base)||base.includes('..')||base.includes('//'))throw Error('Invalid Pages base path');
 base='/'+base.replace(/^\/+|\/+$/g,'');
}
const originInput=argument('--origin')??process.env.GITHUB_PAGES_ORIGIN??(owner?`https://${owner.toLowerCase()}.github.io`:undefined);
if(!originInput)throw Error('Set GITHUB_PAGES_ORIGIN or pass --origin');
const originURL=new URL(originInput);
if(!['https:','http:'].includes(originURL.protocol)||originURL.username||originURL.password||originURL.search||originURL.hash||originURL.pathname!=='/')throw Error('Origin must contain only protocol and hostname');
const origin=originURL.origin;
const previewHost='nasledie-project-design-2026.derectim.chatgpt.site';
const productionHosts=new Set(['nasledieproekt.ru','www.nasledieproekt.ru']);
async function files(dir,relative=''){
 const result=[];
 for(const item of await fs.readdir(path.join(dir,relative),{withFileTypes:true})){
  if(item.name.startsWith('.'))throw Error(`Hidden public input is not allowed: ${relative}/${item.name}`);
  const name=path.posix.join(relative,item.name);
  if(item.isSymbolicLink())throw Error(`Symbolic links are not allowed: ${name}`);
  if(item.isDirectory())result.push(...await files(dir,name));else if(item.isFile())result.push(name);
 }
 return result.sort();
}
const inventory=await files(input);
const available=new Set(inventory);
const pages=inventory.filter(f=>f.endsWith('.html'));
if(pages.length!==586)throw Error(`Expected 586 HTML files, got ${pages.length}`);
function existsURL(pathname){
 let decoded;try{decoded=decodeURIComponent(pathname);}catch{return false;}
 const clean=decoded.replace(/^\//,'');
 return available.has(clean)||available.has(clean.replace(/\/$/,'')+'/index.html')||(!clean&&available.has('index.html'));
}
function localPath(value){return base+value;}
function rewriteURL(value){
 if(value.startsWith('/')&&!value.startsWith('//'))return localPath(value);
 if(!/^https?:\/\//i.test(value))return value;
 const url=new URL(value);
 if(url.hostname===previewHost)return origin+localPath(url.pathname)+url.search+url.hash;
 if(productionHosts.has(url.hostname)){
  url.pathname=url.pathname.replace(/\/%22%3e$/i,'/');
  if(existsURL(url.pathname))return localPath(url.pathname)+url.search+url.hash;
 }
 return value;
}
function rewriteHTML(text){
 return text
  .replace(/\b(href|src|action|poster|data-search-url)=(['"])(.*?)\2/gi,(_,name,quote,value)=>`${name}=${quote}${rewriteURL(value)}${quote}`)
  .replace(/\bcontent=(['"])(https?:\/\/[^'"]+)\1/gi,(_,quote,value)=>`content=${quote}${rewriteURL(value)}${quote}`)
  .replace(/\bsrcset=(['"])(.*?)\1/gi,(_,quote,value)=>`srcset=${quote}${value.split(',').map(item=>{const [url,...descriptor]=item.trim().split(/\s+/);return [rewriteURL(url),...descriptor].join(' ');}).join(', ')}${quote}`)
  .replace(/<script\b([^>]*\btype=['"]application\/ld\+json['"][^>]*)>([\s\S]*?)<\/script>/gi,(_,attrs,json)=>`<script${attrs}>${JSON.stringify(rewriteJSON(JSON.parse(json)))}</script>`);
}
function rewriteJSON(value){
 if(typeof value==='string')return rewriteURL(value);
 if(Array.isArray(value))return value.map(rewriteJSON);
 if(value&&typeof value==='object')return Object.fromEntries(Object.entries(value).map(([key,item])=>[key,rewriteJSON(item)]));
 return value;
}
function rewriteCSS(text){
 return text
  .replace(/url\(\s*(['"]?)(\/[^)'"\s]+)\1\s*\)/g,(_,quote,url)=>`url(${quote}${rewriteURL(url)}${quote})`)
  .replace(/(@import\s+)(['"])(\/[^'"]+)\2/g,(_,prefix,quote,url)=>`${prefix}${quote}${rewriteURL(url)}${quote}`);
}
function rewriteJS(text){
 // Rewrite actual loading/navigation expressions, not route constants used in comparisons.
 // In particular, morePaths and the appHomePath fallback remain source-relative.
 return text
  .replace(/(\b(?:fetch|import)\(\s*)(['"])(\/(?!\/)[^'"\r\n]*)\2/g,(_,prefix,quote,url)=>`${prefix}${quote}${rewriteURL(url)}${quote}`)
  .replace(/(\b[a-zA-Z_$][\w$]*\.href\s*=\s*)(['"])(\/(?!\/)[^'"\r\n]*)\2/g,(_,prefix,quote,url)=>`${prefix}${quote}${rewriteURL(url)}${quote}`);
}
if(path.resolve(output)!==path.join(root,'_site'))throw Error('Unsafe output path');
await fs.rm(output,{recursive:true,force:true});
await fs.mkdir(output,{recursive:true});
let bytes=0;
for(const name of inventory){
 if(/(^|\/)(downloads|research|wordpress-theme|node_modules)(\/|$)/i.test(name))throw Error(`Private input directory: ${name}`);
 const target=path.join(output,name);await fs.mkdir(path.dirname(target),{recursive:true});
 let data=await fs.readFile(path.join(input,name));
 if(name.endsWith('.html'))data=Buffer.from(rewriteHTML(data.toString('utf8')));
 else if(name.endsWith('.css'))data=Buffer.from(rewriteCSS(data.toString('utf8')));
 else if(name==='app.js')data=Buffer.from(rewriteJS(data.toString('utf8')));
 else if(name==='search-index.json')data=Buffer.from(JSON.stringify(rewriteJSON(JSON.parse(data.toString('utf8')))));
 await fs.writeFile(target,data);bytes+=data.length;
}
await fs.writeFile(path.join(output,'.nojekyll'),'');
console.log(JSON.stringify({result:'PASS',html:pages.length,files:inventory.length+1,bytes,origin,base:base||'/',output:'_site'},null,2));

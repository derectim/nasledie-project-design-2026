# Наследие-Проект - клиентский просмотр

Статический макет: 586 страниц, услуги, компания, контакты, лицензии и все записи блога. Это демонстрация будущей темы WordPress. Формы в демонстрации не отправляют обращения.

В пакете нет WordPress, базы данных, административных файлов или архива темы. Изображения статей и подлинные сканы документов загружаются с действующего сайта. Служебные ссылки на личные переписки удалены с сохранением текста.

## Публикация

1. Загрузите содержимое этого каталога в отдельный публичный репозиторий GitHub.
2. В **Settings > Pages > Build and deployment > Source** выберите **GitHub Actions**.
3. Запустите workflow **Publish client preview** или отправьте изменения в ветку `main`.

Адрес проекта будет `https://OWNER.github.io/REPOSITORY/`. Скрипт автоматически учитывает имя репозитория. Для репозитория `OWNER.github.io` поддерживается корневой адрес. При использовании собственного домена workflow получает адрес из настроек Pages.

Внешняя публикация общедоступна. Метки `noindex,nofollow` и `robots.txt` сохранены, чтобы поисковые системы не индексировали демонстрацию. Это не ограничение доступа.

## Локальная сборка

Нужен Node.js 22 или новее, установка пакетов не требуется.

```text
node prepare-pages.mjs --base /example/ --origin https://owner.github.io
node check-pages.mjs --base /example/ --origin https://owner.github.io
```

Либо задайте `GITHUB_REPOSITORY=OWNER/REPOSITORY` и при необходимости `GITHUB_PAGES_ORIGIN=https://owner.github.io`. Результат записывается в `_site/`; исходные файлы в `public/` остаются неизменными. Все переходы, поиск, CSS, загрузка анимаций и адреса canonical/og адаптируются при сборке.

Workflow использует [официальные действия GitHub Pages](https://docs.github.com/en/pages/getting-started-with-github-pages/using-custom-workflows-with-github-pages).
